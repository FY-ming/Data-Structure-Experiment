#pragma once
class Tourist
{
};

